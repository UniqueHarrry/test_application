package com.App.service;


import java.util.List;
import java.util.stream.Collectors;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.App.Exception.ResourceNotFoundException;
import com.App.Model.Student;
import com.App.Model.StudentDto;
import com.App.Model.Teacher;
import com.App.repository.StudentRepository;
import com.App.repository.TeacherRepository;

@Service
public class StudentServiceImp implements StudentService {
	
	private StudentRepository studentRepository;
	private TeacherRepository teacherRepository;

	@Autowired
	public StudentServiceImp(StudentRepository studentRepository, TeacherRepository teacherRepository) {
		super();
		this.studentRepository = studentRepository;
		this.teacherRepository = teacherRepository;
	}

	@Override
	public StudentDto createStudentByTeacherId(StudentDto studentDto, int TeacherId) {
		Student student = mapToEntity(studentDto);
		Teacher teacher = teacherRepository.findById(TeacherId).orElseThrow(()-> new ResourceNotFoundException("TeacherId", "teacherId", TeacherId)); 
		
		student.setTeachers(teacher);
		studentRepository.save(student);
		
		return mapToDto(student);
	}
	
	@Override
	public List<StudentDto> getStudentByTeacherId(int teacherId) {
		 List<Student> students = studentRepository.findByTeachersId(teacherId);
		return students.stream().map(student -> mapToDto(student)).collect(Collectors.toList());
	}
	
	public Student mapToEntity(StudentDto studentDto) {
		Student student = new Student();
		student.setMarks(studentDto.getMarks());
		student.setName(studentDto.getName());
		return student;
	}
	
	public StudentDto mapToDto(Student student) {
		StudentDto studentDto = new StudentDto();
		studentDto.setId(student.getId());
		studentDto.setMarks(student.getMarks());
		studentDto.setName(student.getName());
		return studentDto;
	}

	

}
