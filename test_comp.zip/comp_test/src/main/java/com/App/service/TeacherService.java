package com.App.service;

import java.util.List;

import com.App.Model.TeacherDto;

public interface TeacherService {

	TeacherDto createTeacher(TeacherDto teacherDto);
	
	List<TeacherDto> getAllTeacher();
	
	TeacherDto getTecherById(int id);
	
	TeacherDto upadateTeacherById(int id, TeacherDto teacherDto); 

	void deleteTeacherById(int id);
}
