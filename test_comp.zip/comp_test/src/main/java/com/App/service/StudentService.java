package com.App.service;

import java.util.List;

import com.App.Model.StudentDto;

public interface StudentService {

	StudentDto createStudentByTeacherId(StudentDto studentDto, int TeacherId );
	
	List<StudentDto> getStudentByTeacherId(int teacherId);
	
//	List<StudentDto> getAllStudent();
	
	
}
