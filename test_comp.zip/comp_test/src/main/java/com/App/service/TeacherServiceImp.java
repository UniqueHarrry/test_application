package com.App.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.App.Exception.ResourceNotFoundException;
import com.App.Model.Teacher;
import com.App.Model.TeacherDto;
import com.App.repository.TeacherRepository;

@Service
public class TeacherServiceImp implements TeacherService {
	
	private TeacherRepository teacherRepository;
	
	@Autowired
	public TeacherServiceImp(TeacherRepository teacherRepository) {
		super();
		this.teacherRepository = teacherRepository;
	}

	@Override
	public TeacherDto createTeacher(TeacherDto teacherDto) {
		Teacher teacher = mapToEntity(teacherDto);
		Teacher teacherResponse =teacherRepository.save(teacher);
		return mapToDto(teacherResponse);
	}
	
	@Override
	public List<TeacherDto> getAllTeacher() {
		List<Teacher> teachers = teacherRepository.findAll();
		return teachers.stream().map(teacher -> mapToDto(teacher)).collect(Collectors.toList());
	}
	
	@Override
	public TeacherDto getTecherById(int id) {
		Teacher teacher =teacherRepository.findById(id).orElseThrow(()-> new ResourceNotFoundException("Teacher", "TeacherId", id));
		return mapToDto(teacher);
	}
	
	@Override
	public TeacherDto upadateTeacherById(int id, TeacherDto teacherDto) {
		Teacher teacher =teacherRepository.findById(id).orElseThrow(()-> new ResourceNotFoundException("Teacher", "TeacherId", id));
		teacher.setName(teacherDto.getName());
		teacher.setSubject(teacherDto.getSubject());
		teacherRepository.save(teacher);
		return mapToDto(teacher);
	}
	
	@Override
	public void deleteTeacherById(int id) {
		Teacher teacher =teacherRepository.findById(id).orElseThrow(()-> new ResourceNotFoundException("Teacher", "TeacherId", id));
		teacherRepository.delete(teacher);
	}
	
	public Teacher mapToEntity(TeacherDto teacherDto) {
		Teacher teacher = new Teacher();
		teacher.setName(teacherDto.getName());
		teacher.setSubject(teacherDto.getSubject());
		return teacher;
	}
	
	public TeacherDto mapToDto(Teacher teacher) {
		TeacherDto teacherDto = new TeacherDto();
		teacherDto.setId(teacher.getId());
		teacherDto.setName(teacher.getName());
		teacherDto.setSubject(teacher.getSubject());
		return teacherDto;
	}

	

}
