package com.App.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import com.App.Model.StudentDto;
import com.App.Model.TeacherDto;
import com.App.service.StudentServiceImp;
import com.App.service.TeacherServiceImp;

import jakarta.xml.ws.Response;

@RestController
@RequestMapping("/api")
public class MyController {

	private TeacherServiceImp teacherService;
	private StudentServiceImp studentService;
	
	@Autowired
	public MyController(TeacherServiceImp teacherService, StudentServiceImp studentService) {
		super();
		this.teacherService = teacherService;
		this.studentService = studentService;
	}

	@PostMapping("/teacher")
	public ResponseEntity<TeacherDto> createTeacher(@RequestBody TeacherDto teacherDto){
		return new ResponseEntity<TeacherDto>(teacherService.createTeacher(teacherDto), HttpStatus.CREATED);
	}
	
	@GetMapping("/teacher")
	public ResponseEntity<List<TeacherDto>> getAllTeacher(){
		return new ResponseEntity<List<TeacherDto>>( teacherService.getAllTeacher(), HttpStatus.OK);
	}
	
	@GetMapping("teacher/{id}")
	public ResponseEntity<TeacherDto> getTeacherById(@PathVariable int id){
		return new ResponseEntity<TeacherDto>(teacherService.getTecherById(id), HttpStatus.OK);
	}
	
	@PutMapping("/teacher/{id}")
	public ResponseEntity<TeacherDto> updateTeacherById(@PathVariable int id, @RequestBody TeacherDto teacherDto){
		return new ResponseEntity<TeacherDto>(teacherService.upadateTeacherById(id, teacherDto), HttpStatus.OK);
	}
	
	@DeleteMapping("/teacher/{id}")
	public ResponseEntity<String> deleteTeacherById(@PathVariable int id){
		teacherService.deleteTeacherById(id);
		return new ResponseEntity<String>("Teacher Succesfully Deleted",HttpStatus.OK); 
	}
	
	@PostMapping("/teacher/{TeacherId}/student")
	public ResponseEntity<StudentDto> createStudentByTeacherId( @PathVariable int TeacherId, @RequestBody StudentDto studentDto){
		return new ResponseEntity<StudentDto>(studentService.createStudentByTeacherId(studentDto, TeacherId), HttpStatus.CREATED);
	}
	
	@GetMapping("/teacher/{teacherId}/student")
	public ResponseEntity<List<StudentDto>> getStudentByTeacherId(@PathVariable int teacherId){
		return new ResponseEntity<List<StudentDto>>(studentService.getStudentByTeacherId(teacherId), HttpStatus.OK);
	}
	
}
