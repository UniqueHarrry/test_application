package com.App.Model;

import lombok.Data;

@Data
public class StudentDto {
	private int id;
	private String name;
	private String marks;
}
