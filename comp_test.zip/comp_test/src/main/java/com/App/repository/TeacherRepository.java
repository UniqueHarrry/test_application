package com.App.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.App.Model.Teacher;
import com.App.Model.TeacherDto;

public interface TeacherRepository extends JpaRepository<Teacher, Integer> {

}
